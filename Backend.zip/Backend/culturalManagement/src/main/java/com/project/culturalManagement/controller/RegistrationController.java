 package com.project.culturalManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.culturalManagement.model.Registration;
import com.project.culturalManagement.service.RegistrationService;


@RestController
@RequestMapping("/Registration")
@CrossOrigin(origins = "http://localhost:4200/")
public class RegistrationController {

	@Autowired
	private RegistrationService rService;
	
	//create
	@PostMapping("/add")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Registration addReg(@RequestBody Registration registration)
	{
		return rService.newReg(registration);
	}
	
	//update
	@PutMapping("/update")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Registration updateReg(@RequestBody Registration registration)
	{
		return rService.updateReg(registration);
	}
	
	//read
	@GetMapping("/getById/{id}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Optional<Registration> getRegById(@PathVariable int id)
	{
		Optional<Registration> reg =  rService.regById(id);
		
		return reg;
	}
	
	@GetMapping("/getAll")
	@CrossOrigin(origins = "http://localhost:4200/")
	public List<Registration> getAllReg()
	{
		return rService.allReg();
	}
	
	//delete
	@DeleteMapping("/deleteAll")
	@CrossOrigin(origins = "http://localhost:4200/")
	public void deleteAllReg()
	{
		rService.deleteAll();
	}
	
	@DeleteMapping("/deleteById/{id}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public void deleteRegById(@PathVariable int id)
	{
		rService.deleteById(id);
	}
	
	
	//count
	@GetMapping("/count")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Long countOfReg()
	{
		return rService.countOfReg();
	}
	
	@GetMapping("/getByEventId/{eventId}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Registration getRegDetails(@PathVariable Integer eventId) {
		return rService.getRegdetails(eventId);
	}
}
