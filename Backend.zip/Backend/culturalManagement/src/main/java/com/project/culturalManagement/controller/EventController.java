package com.project.culturalManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.culturalManagement.exception.EventNotFoundException;
import com.project.culturalManagement.model.Event;
import com.project.culturalManagement.service.EventService;


@RestController
@RequestMapping("/Event")
@CrossOrigin(origins = "http://localhost:4200/")
public class EventController {

	
	@Autowired
	private EventService eService;
	
	//create
	@PostMapping("/add")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Event addEvent(@RequestBody Event event)
	{
		return eService.newEvent(event);
	}
	
	//update
	@PutMapping("/update")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Event updateEvent(@RequestBody Event event)
	{
		return eService.updateEvent(event);
	}
	
	//read
	@GetMapping("/getById/{id}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Optional<Event> getEventById(@PathVariable int id) throws EventNotFoundException
	{
		return eService.eventById(id);
		
		
	}
	
	@GetMapping("/getAll")
	@CrossOrigin(origins = "http://localhost:4200/")
	public List<Event> getAllEvent()
	{
		return eService.allEvent();
	}
	
	//delete
	@DeleteMapping("/deleteAll")
	@CrossOrigin(origins = "http://localhost:4200/")
	public void deleteAllEvent()
	{
		eService.deleteAll();
	}
	
	@DeleteMapping("/deleteById/{id}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public void deleteEventById(@PathVariable int id) throws EventNotFoundException
	{
		eService.deleteById(id);
	}
	
	
	//count
	@GetMapping("/count")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Long countOfEvent() throws EventNotFoundException
	{
		return eService.countOfEvent();
	}
}
