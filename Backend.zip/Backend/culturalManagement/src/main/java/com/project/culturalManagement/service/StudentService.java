package com.project.culturalManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.culturalManagement.dto.LoginDetails;
import com.project.culturalManagement.exception.StudentNotFoundException;
import com.project.culturalManagement.model.Student;
import com.project.culturalManagement.repository.StudentRepository;


@Service
public class StudentService {

	@Autowired
	private StudentRepository strepo;
	
	//create
	public Student newStu(Student student)
	{
		return strepo.save(student);
	}
	
	//update
	public Student updateStu(Student student)
	{
		return strepo.save(student);
	}
	
	//read
	public List<Student> allStu() throws StudentNotFoundException
	{
		List<Student> student = strepo.findAll();
		if(student.isEmpty()) {
			throw new StudentNotFoundException("Student data is empty");
		}
		return student;
	}
	
	public Optional<Student> stuById(int id) throws StudentNotFoundException
	{
		Optional<Student> s = strepo.findById(id);
		
		if(s.isEmpty()) {
			throw new StudentNotFoundException("Id not Found: "+id);
		}
		
		return s;
	}
	
	//delete
	public void deleteAll()
	{
		strepo.deleteAll();
	}
	
	public void deleteById(int id) throws StudentNotFoundException
	{
		if(id == 0) {
			throw new StudentNotFoundException("Id not Found: "+id);
		}
		strepo.deleteById(id);
	}
	
	//count
	public Long countOfStu()
	{
		return strepo.count();
	}
	///security
	public Student getByEmailAndPassword(LoginDetails login) {
		// TODO Auto-generated method stub
		return strepo.getEmailAndPassword(login.getEmail(), login.getPassword());
	}
}
