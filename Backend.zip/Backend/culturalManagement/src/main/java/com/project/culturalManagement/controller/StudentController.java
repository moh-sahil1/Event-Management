package com.project.culturalManagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.culturalManagement.dto.LoginDetails;
import com.project.culturalManagement.exception.StudentNotFoundException;
import com.project.culturalManagement.model.Student;
import com.project.culturalManagement.service.StudentService;

@RestController
@RequestMapping("/Student")
@CrossOrigin(origins = "http://localhost:4200/")
public class StudentController {

	
	@Autowired
	private StudentService sService;
	
	//create
	@PostMapping("/add")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Student addStu(@RequestBody Student student)
	{
		return sService.newStu(student);
	}
	
	//update
	@PutMapping("/update")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Student updateStu(@RequestBody Student student)
	{
		return sService.updateStu(student);
	}
	
	//read
	@GetMapping("/getById/{id}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Optional<Student> getStuById(@PathVariable int id) throws StudentNotFoundException
	{
		Optional<Student> event =  sService.stuById(id);
		
		return event;
	}
	
	@GetMapping("/getAll")
	@CrossOrigin(origins = "http://localhost:4200/")
	public List<Student> getAllStu() throws StudentNotFoundException
	{
		return sService.allStu();
	}
	
	//delete
	@DeleteMapping("/deleteAll")
	@CrossOrigin(origins = "http://localhost:4200/")
	public void deleteAllStu()
	{
		sService.deleteAll();
	}
	
	@DeleteMapping("/deleteById/{id}")
	@CrossOrigin(origins = "http://localhost:4200/")
	public void deleteStuById(@PathVariable int id) throws StudentNotFoundException
	{
		sService.deleteById(id);
	}
	
	
	//count
	@GetMapping("/count")
	@CrossOrigin(origins = "http://localhost:4200/")
	public Long countOfStu()
	{
		return sService.countOfStu();
	}
	
	
	@PostMapping("/login")
	@CrossOrigin(origins = "http://localhost:4200/")
		public Student retriveByEmailAndPassword(@RequestBody LoginDetails loginDetails) {
			return sService.getByEmailAndPassword(loginDetails);
		}
}

