package com.project.culturalManagement.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.project.culturalManagement.model.Student;


public interface StudentRepository extends JpaRepository<Student, Integer>{
	
	@Query(value = "select * from student s where s.email like :email and s.password like :password", nativeQuery = true)
	Student getEmailAndPassword(String email, String password);
	
	Optional<Student> findByEmail(String email);
}
