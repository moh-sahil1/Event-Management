package com.project.culturalManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;

import com.project.culturalManagement.model.Event;

public interface EventRepository extends JpaRepository<Event, Integer> {


}
