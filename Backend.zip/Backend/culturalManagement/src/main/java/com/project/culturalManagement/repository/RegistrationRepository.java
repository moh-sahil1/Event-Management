package com.project.culturalManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.culturalManagement.model.Registration;

public interface RegistrationRepository extends JpaRepository<Registration, Integer> {

}
