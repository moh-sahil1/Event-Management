package com.project.culturalManagement.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;


@Entity
public class Event {

	@Id	
	private int eventId;
	private String eventName;
	private String venue;
	private String time;
	
	
	

	@OneToMany(mappedBy="event", cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Registration> registration;
	
	public List<Registration> getRegistration() {
		return registration;
	}

	public void setRegistration(List<Registration> registration) {
		this.registration = registration;
	}





	


	public Event(int eventId, String eventName, String venue, String time) {
		super();
		this.eventId = eventId;
		this.eventName = eventName;
		this.venue = venue;
		this.time = time;
	}


	public int getEventId() {
		return eventId;
	}


	public void setEventId(int eventId) {
		this.eventId = eventId;
	}


	public String getEventName() {
		return eventName;
	}


	public void setEventName(String eventName) {
		this.eventName = eventName;
	}


	public String getVenue() {
		return venue;
	}


	public void setVenue(String venue) {
		this.venue = venue;
	}


	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}
	
	public Event() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

