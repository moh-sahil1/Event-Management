package com.project.culturalManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.culturalManagement.model.Registration;
import com.project.culturalManagement.repository.RegistrationRepository;


@Service
public class RegistrationService {
	
	
	@Autowired
	private RegistrationRepository regrepo;
	
	//create
	public Registration newReg(Registration registration)
	{
		return regrepo.save(registration);
	}
	
	//update
	public Registration updateReg(Registration registration)
	{
		return regrepo.save(registration);
	}
	
	//read
	public List<Registration> allReg()
	{
		return regrepo.findAll();
	}
	
	public Optional<Registration> regById(int id)
	{
		
		return regrepo.findById(id);
	}
	
	//delete
	public void deleteAll()
	{
		regrepo.deleteAll();
	}
	
	public void deleteById(int id)
	{
		regrepo.deleteById(id);
	}
	
	//count
	public Long countOfReg()
	{
		return regrepo.count();
	}

	
	/////
	public Registration getRegdetails(Integer eventId) {
		
		List<Registration> reg = regrepo.findAll();
		
		Registration registration = null;
		
		for(int i=reg.size()-1;i>=0;i--) {
			if(eventId == reg.get(i).getEvent().getEventId()) {
				registration = reg.get(i);
				break;
			}
		}
		
		return registration;
	}
}

