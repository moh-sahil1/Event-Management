package com.project.culturalManagement.model;

public class AuthenticationResponse {
	
	private String token;
	
    private Student user;
    private String message;

    public AuthenticationResponse(Student user, String message, String token) {
        this.user = user;
        this.message = message;
        this.token = token;
    }
    
    public String getToken() {
    	return token;
    }
    
	public Student getUser() {
        return user;
    }

    public String getMessage() {
        return message;
    }
}
