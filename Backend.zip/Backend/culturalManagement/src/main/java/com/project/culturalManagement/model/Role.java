package com.project.culturalManagement.model;

public enum Role {
	USER,
	ADMIN
}
