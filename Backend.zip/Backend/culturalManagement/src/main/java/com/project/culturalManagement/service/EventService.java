package com.project.culturalManagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.culturalManagement.exception.EventNotFoundException;
import com.project.culturalManagement.model.Event;
import com.project.culturalManagement.repository.EventRepository;


@Service
public class EventService {

	
	@Autowired
	private EventRepository eventrepo;
	
	//create
	public Event newEvent(Event event)
	{
		return eventrepo.save(event);
	}
	
	
		
	//read
	public List<Event> allEvent()
	{
		
		return eventrepo.findAll();
	}
	
	public Optional<Event> eventById(int id) throws EventNotFoundException
	{
		Optional<Event> event =  eventrepo.findById(id);
		
		if(event.isEmpty()) {
			throw new EventNotFoundException("Event not Found for this id:"+id);
		}
		
		return event;
	}
	
	//delete
	public void deleteAll()
	{
		eventrepo.deleteAll();
	}
	
	public void deleteById(int id) throws EventNotFoundException
	{
		if(id == 0) {
			throw new EventNotFoundException("Event not Found:"+id);
		}
		
		eventrepo.deleteById(id);
	}
	
	//count
	public Long countOfEvent() throws EventNotFoundException
	{
		long count = eventrepo.count();
		
		if(count == 0) {
			throw new EventNotFoundException("Event count is zero");
		}
		
		return count;
	}
	//update
	public Event updateEvent(Event event)
	{
//		eventrepo.
		return eventrepo.saveAndFlush(event);
	}

}
