package com.project.culturalManagement.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.project.culturalManagement.repository.StudentRepository;

@Service
public class UserDetailsServiceImp implements UserDetailsService {

    private final StudentRepository repository;

    public UserDetailsServiceImp(StudentRepository repository) {
        this.repository = repository;
    }

    @Override//load the user specific data
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        return repository.findByEmail(email)
                .orElseThrow(()-> new UsernameNotFoundException("User not found"));
    }
}
