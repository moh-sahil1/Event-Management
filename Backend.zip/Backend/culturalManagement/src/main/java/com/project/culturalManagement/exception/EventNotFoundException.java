package com.project.culturalManagement.exception;

public class EventNotFoundException extends Exception {
	
	public EventNotFoundException(String message){
		super(message);
	}
}
