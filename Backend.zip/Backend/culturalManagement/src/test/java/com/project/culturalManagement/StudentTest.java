package com.project.culturalManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.project.culturalManagement.exception.StudentNotFoundException;
import com.project.culturalManagement.service.StudentService;



@SpringBootTest
public class StudentTest {

	
	@Autowired
	StudentService service;
	
	@Test
	void studentCountTest() {
		assertEquals(6, service.countOfStu());
	}
	
	@Test
	void allStudentTest() throws StudentNotFoundException {
		assertNotNull(service.allStu());
	}
	
	@Test
	void findStudentByIdTest(){
//		if(service.stuById(1)==null) {
//			throw new StudentNotFoundException("Studend doest exist");
//		}
//		else
		try {
		assertNotNull(service.stuById(1));
		}
		catch(StudentNotFoundException e) {
		System.out.println("student cannot be found");
		}
	}
	

}
