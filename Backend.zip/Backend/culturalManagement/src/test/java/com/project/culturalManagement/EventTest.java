package com.project.culturalManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.culturalManagement.exception.EventNotFoundException;
import com.project.culturalManagement.service.EventService;



@SpringBootTest
public class EventTest {

	
	@Autowired
	EventService eservice;
	
	@Test
	void eventCountTest() throws EventNotFoundException {
		assertEquals(3, eservice.countOfEvent());
	}
	
	@Test
	void allEventTest() {
		assertNotNull(eservice.allEvent());
	}
	
	@Test
	void findEventByIdTest() throws EventNotFoundException {
		assertNotNull(eservice.eventById(1));
	}
}
