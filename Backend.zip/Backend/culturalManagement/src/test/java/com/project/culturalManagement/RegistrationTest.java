package com.project.culturalManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.project.culturalManagement.service.RegistrationService;



@SpringBootTest
public class RegistrationTest {

	
	@Autowired
	RegistrationService rservice;
	
	@Test
	void registrationCountTest() {
		assertEquals(6, rservice.countOfReg());
	}
	
	@Test
	void allRegistartionTest() {
		assertNotNull(rservice.allReg());
	}
	
	@Test
	void findRegistrationByIdTest() {
		assertNotNull(rservice.regById(3));
	}
}
