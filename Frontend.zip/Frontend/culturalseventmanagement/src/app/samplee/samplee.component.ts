import { Component } from '@angular/core';

@Component({
  selector: 'app-samplee',
  templateUrl: './samplee.component.html',
  styleUrl: './samplee.component.css'
})
export class SampleeComponent {

}
