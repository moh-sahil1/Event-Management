import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RegisterComponent } from './register/register.component';
import { EventComponent } from './event/event.component';
import { StudentDashboardComponent } from './student-dashboard/student-dashboard.component';
import { HttpClientModule } from '@angular/common/http';
import { EventRegisterComponent } from './event-register/event-register.component';
import { RegisterPageComponent } from './register-page/register-page.component';
import { FormsModule, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { AdminComponent } from './admin/admin.component';
import { AddeventsComponent } from './addevents/addevents.component';
import { ManageregisComponent } from './manageregis/manageregis.component';
import { ManagestuComponent } from './managestu/managestu.component';
// import { SampleeComponent } from './samplee/samplee.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { authGuard, authGuardUser } from './auth.guard';

const routes: Routes = [
  { path: '' , component: HomeComponent },
  { path : 'home', component: HomeComponent},
  { path:'register' , component: RegisterComponent },
  { path:'studentDB' , component: StudentDashboardComponent, canActivate:[authGuardUser]},
  { path:'studentDB/registerpage/:eventId' , component: RegisterPageComponent},
  { path: 'studentDB/registerpage/:eventId/eventRegistration', component: EventRegisterComponent},
  { path: 'admin' , component: AdminComponent , canActivate:[authGuard]},
  { path: 'admin/manageevents' , component: AddeventsComponent ,canActivate:[authGuard]},
  { path: 'admin/manageregis' , component: ManageregisComponent,canActivate:[authGuard]},
  { path: 'admin/managestudents' , component: ManagestuComponent ,canActivate:[authGuard]},
  // { path: 'simplee' , component: SampleeComponent},
  { path: 'login' , component: LoginpageComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarComponent,
    RegisterComponent,
    EventComponent,
    StudentDashboardComponent,
    EventRegisterComponent,
    RegisterPageComponent,
    AdminComponent,
    AddeventsComponent,
    ManageregisComponent,
    ManagestuComponent,
    // SampleeComponent,
    LoginpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule.forRoot(routes),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
