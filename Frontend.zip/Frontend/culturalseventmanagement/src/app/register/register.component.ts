import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EventService } from '../event.service';


export class StudentD{
  id: any;
  userName: any;
  email: any;
  password: any;
  mobile: any;
  department: any;
  yearOfStudy: any;
  college: any;
}
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {


  
  //validations
  contactForm = new FormGroup({
    password : new FormControl('', [Validators.required]),
    email : new FormControl('', [Validators.required, Validators.email]),
    mobileNo : new FormControl('', [Validators.required,Validators.minLength(10),Validators.maxLength(10)]),
    username : new FormControl('', [Validators.required]),
    dept : new FormControl('', [Validators.required]),
    year : new FormControl('', [Validators.required]),
    college : new FormControl('', [Validators.required])
  })


 student: StudentD = new StudentD();

 constructor (private eventService :EventService){}

 addStudent(){
  this.eventService.addStudent(this.student).subscribe(data=>{
alert("Registration Successful!");
  })
 }
}
