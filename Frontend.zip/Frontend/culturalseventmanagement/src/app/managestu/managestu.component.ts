import { Component } from '@angular/core';
import { EventService } from '../event.service';


export class Students{
email: any;
id: any;
userName: any;
mobile: any;
department: any;
yearOfStudy: any;
college: any;
    constructor(
      id:any,
      userName:any,
      email:any,
      mobile:any,
      department:any,
      yearOfStudy:any,
      college:any,


    )
   {} 
  }
  
@Component({
  selector: 'app-managestu',
  templateUrl: './managestu.component.html',
  styleUrl: './managestu.component.css'
})
export class ManagestuComponent {

students: Students[] | undefined
ngOnInit(): void{
  this.showStudents();
}
constructor(private eventService: EventService){}
showStudents(){
  this.eventService.getAllStudents().subscribe(data =>{
    this.students = data as Students[];
  })

}
}
