import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { EventService } from '../event.service';

export class EventDetails{
eventId: any;
eventName: any;
venue: any;
time: any;
  constructor(
  eventId:any,
  eventName:any,
  venue:any,
  time:any
  ){}
  }

@Component({
  selector: 'app-student-dashboard',
  templateUrl: './student-dashboard.component.html',
  styleUrl: './student-dashboard.component.css'
})
export class StudentDashboardComponent {

  name: any;

  eventDetails:EventDetails[] = [];

  ngOnInit(): void{
    this.name = localStorage.getItem("name");
    this.getDetails();
  }


  constructor(private eventService: EventService, private router: Router){}

  getDetails(){
    this.eventService.retrieveEventDetails().subscribe(data =>{
      this.eventDetails = data as EventDetails[];
    })
  }

  logout(){
    localStorage.clear();
    this.eventService.logout({"email":localStorage.getItem("email") , "password" : localStorage.getItem("password")})
    this.router.navigateByUrl("");

  }

}
