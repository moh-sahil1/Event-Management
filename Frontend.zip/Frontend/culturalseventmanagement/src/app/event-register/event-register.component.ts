import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventService } from '../event.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';



export class Eventreg{
  public regId!: number;
  public event!: {
    eventId: any;
    eventName: any;
    venue: any;
    time: any;
  }; 
  public student!: {
    id: any;
    userName: any;
    email: any;
    mobile: any;
    department: any;
    yearOfStudy: any;
    college: any;
  };
}

@Component({
  selector: 'app-event-register',
  templateUrl: './event-register.component.html',
  styleUrl: './event-register.component.css'
})
export class EventRegisterComponent {
  
  
  eventId!: number;


  regEvent:Eventreg = new Eventreg();
  constructor(private eventService: EventService, private route: ActivatedRoute){}

  ngOnInit():void{
    this.eventId =  Number(this.route.snapshot.paramMap.get('eventId'));
    this.getregistrationDetails();
    console.log(this.eventId);

  }

  getregistrationDetails(){
    this.eventService.getRegistrationDetails(this.eventId).subscribe(data =>{
      
      console.log(data)
      this.regEvent = data as Eventreg;
      console.log(this.regEvent.regId);
    });
  }

    //to download as pdf
 
    public downloadFullPagePDF(): void {
      html2canvas(document.body).then(canvas => {
        let pdf = new jsPDF('p', 'mm', 'a4');
        let imgWidth = 210; // A4 width in mm
        let pageHeight = 297;  // A4 height in mm
        let imgHeight = canvas.height * imgWidth / canvas.width;
        let heightLeft = imgHeight;
        let position = 0;
   
        pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, position, imgWidth, imgHeight);
        pdf.save('Event-Registration.pdf');
      });
    }
}



