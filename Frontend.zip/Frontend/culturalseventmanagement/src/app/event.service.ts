import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class EventService {

  constructor(private httpClient: HttpClient) { }

  logout(login : any){
    this.httpClient.get('http://localhost:8080/logout',login);
  }

  userExist(login : any){
      return this.httpClient.post('http://localhost:8080/login',login);
  }

  // userExist(login : any){
  //   return this.httpClient.post('http://localhost:8080/Student/login',login);
  // }

  retrieveEventDetails(){
     return this.httpClient.get('http://localhost:8080/Event/getAll');
  }

  // addStudent(student: any){
  //   return this.httpClient.post('http://localhost:8080/Student/add',student)
  // }

  addStudent(student: any){
      return this.httpClient.post('http://localhost:8080/register',student)
  }

  addEvent(eventDetails: any){
    return this.httpClient.post('http://localhost:8080/Event/add',eventDetails)
  }
  updateEvent(eventDetails: any){
    return this.httpClient.put('http://localhost:8080/Event/update',eventDetails)
  }
  deleteEvent(eventId:any){
    return this.httpClient.delete(`http://localhost:8080/Event/deleteById/${eventId}`)
  }
  registerevent(registerationDetails: any){
    return this.httpClient.post('http://localhost:8080/Registration/add',registerationDetails);
  }

  getAllStudents(){
    return this.httpClient.get('http://localhost:8080/Student/getAll');
  }

  getAllAdmin(){
    return this.httpClient.get('http://localhost:8080/Admin/getAll');
  }
  getAllRegistration(){
    return this.httpClient.get('http://localhost:8080/Registration/getAll');
  }
  countOfStudent(){
    return this.httpClient.get('http://localhost:8080/Student/count');
  }
  countOfEvent(){
    return this.httpClient.get('http://localhost:8080/Event/count');
  }
  countOfRegistration(){
    return this.httpClient.get('http://localhost:8080/Registration/count');
  }
  getRegistrationById(id:any){
    return this.httpClient.get(`http://localhost:8080/Registration/getById/${id}`);
  }

  getRegistrationDetails(eventId: number){
    return this.httpClient.get(`http://localhost:8080/Registration/getByEventId/${eventId}`);
  }
}
