import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EventService } from '../event.service';

export class  LoginDetails{
  email:string;
  password:string;
  constructor(){
    this.email='',
    this.password=''
  }
}

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrl: './loginpage.component.css'
})
export class LoginpageComponent {


  contactForm = new FormGroup({
    password : new FormControl('', [Validators.required]),
    email : new FormControl('', [Validators.required, Validators.email])
  })

  user:LoginDetails = new LoginDetails();


  constructor(private router : Router, private EventService: EventService){}

  loginUser(){
    if(this.user.email==="admin@gmail.com" && this.user.password==="admin@123"){
      localStorage.setItem("role","ADMIN");
      this.router.navigate(["/admin"]);
    }
    else{
    this.EventService.userExist({"email": this.user.email,"password": this.user.password}).subscribe(
      (data: any) => {
        if(data){
          console.log(data);
          localStorage.setItem("id",data.user.id);
          localStorage.setItem("name",data.user.userName);
          localStorage.setItem("token",data.token);
          localStorage.setItem("role",data.user.role);
          localStorage.setItem("email",this.user.email);
          localStorage.setItem("password",this.user.password);
          this.router.navigate(["/studentDB"]);
        }
        else{
          alert("Invalid Credentials");
        }
      }
    )
    }
  }
}
