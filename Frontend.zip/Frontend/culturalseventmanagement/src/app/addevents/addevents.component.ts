import { Component } from '@angular/core';
import { EventService } from '../event.service';

export class EventDetailsInAdmin{
  eventId:any;
  eventName:any;
  venue:any;
  time:any;
}

export class NewEvent{
eventId: any;
eventName: any;
venue: any;
time: any;
  constructor(
    eventId:any,
    eventName:any,
    venue:any,
    time:any,
  )
 {} 
}

@Component({
  selector: 'app-addevents',
  templateUrl: './addevents.component.html',
  styleUrl: './addevents.component.css'
})
export class AddeventsComponent {

event: EventDetailsInAdmin = new EventDetailsInAdmin();
events: NewEvent[] | undefined;
ngOnInit(): void{
  this.showEvent();
}
constructor(private eventService: EventService){}
showEvent(){
  this.eventService.retrieveEventDetails().subscribe(data =>{
    this.events = data as NewEvent[];
  })

}
addEvent(){
  this.eventService.addEvent(this.event).subscribe(data =>{
    console.log(data);
    alert("NEW EVENT ADDED SUCCESSFULLY!");
    this.showEvent();
  })
}

updateEvent(){
  this.eventService.updateEvent(this.event).subscribe(data =>{
    console.log(data);
    alert("EVENT DETAILS EDITED SUCCESSFULLY!");
    this.showEvent();
  })
}

deleteEvent(id:number){
  this.eventService.deleteEvent(id).subscribe(data =>{
    console.log(data);
    alert("EVENT DELETED SUCCESSFULLY!");
    this.showEvent();
  })
}
}
///////////////////////////////////////////////////////////////////////////////



