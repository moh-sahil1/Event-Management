import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
 
export const authGuard: CanActivateFn = (route, state) => {
  debugger;
  const router = inject(Router);
  var role = localStorage.getItem('role');
  // var token = localStorage.getItem('token');
    if(role === 'ADMIN'){
      return true;
    }
    else{
      router.navigateByUrl('');
      return false;
    }
  }

  export const authGuardUser: CanActivateFn = (route, state) => {
    var role = localStorage.getItem('role');
    var token = localStorage.getItem('token');
    const router = inject(Router);
      if(token!=null){
        if(role === 'USER'){
          return true;
        }
        else{
          router.navigateByUrl('');
          return false;
        }
      }

      return false;
  }


   
 