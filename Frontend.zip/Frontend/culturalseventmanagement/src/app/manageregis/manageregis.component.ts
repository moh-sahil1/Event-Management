import { Component } from '@angular/core';
import { EventService } from '../event.service';

export class RegistrationDetailsInAd{
regId: any;
event: any;
student: any;
  constructor(
    regId:any,
    event:{
      eventId:any;
      eventName:any;
      venue:any;
      time:any;
    },
    student:{
      id:any;
      userName:any;
      email:any;
      password:any;
      mobile:any;
      department:any;
      yearOfStudy:any;
      college:any;
    }
  ){}
}

@Component({
  selector: 'app-manageregis',
  templateUrl: './manageregis.component.html',
  styleUrl: './manageregis.component.css'
})
export class ManageregisComponent {

 regisD: RegistrationDetailsInAd[] | undefined;

 ngOnInit(): void{
  this.showRegis();
  console.log(this.regisD);
 }

 constructor(private eventService: EventService){}
 
 showRegis(){
  this.eventService.getAllRegistration().subscribe(data =>{
    this.regisD = data as RegistrationDetailsInAd[];
  });
}



}

 
