import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageregisComponent } from './manageregis.component';

describe('ManageregisComponent', () => {
  let component: ManageregisComponent;
  let fixture: ComponentFixture<ManageregisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ManageregisComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(ManageregisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
