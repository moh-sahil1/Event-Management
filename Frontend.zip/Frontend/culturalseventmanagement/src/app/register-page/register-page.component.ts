import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventService } from '../event.service';

export class RegPage{
  regId:any;
  event:any={
    "eventId":"" 
  };
  student={
    "id":""
  };
}
@Component({
  selector: 'app-register-page',
  templateUrl: './register-page.component.html',
  styleUrl: './register-page.component.css'
})
export class RegisterPageComponent {


  id!: number;

  studentId: any;
  sname: string | null | undefined;

  regPage:RegPage = new RegPage();
  

  ngOnInit(): void{
    this.id =  Number(this.route.snapshot.paramMap.get('eventId'));
    this.studentId = localStorage.getItem("id");
    this.sname = localStorage.getItem("name");
    this.regPage.student.id = this.studentId;
    this.regPage.event.eventId=this.id;
  }

  constructor(private route : ActivatedRoute, private service: EventService){}

  register(){
    this.service.registerevent(this.regPage).subscribe();
    alert("REGISTRATION SUCCESSFUL!");
  }
}
